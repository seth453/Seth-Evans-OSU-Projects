#include <iostream>
using namespace std;

//print (num_spaces) white spaces
void print_spaces(int num_spaces) {
    for (int i = 0; i < num_spaces; i++) {
        cout << " ";
    }
}

//print stars, with white spaces in between
void print_stars(int num_stars) {
    for (int i = 0; i < num_stars; i++) {
        if (i == 0 || i == num_stars - 1) {
            cout << "*";
        } else {
            cout << " ";
        }
    }
    cout << endl;
}


void pattern(int n, int col) {
    //your code here:
    
}

int main() {
    int n, col;
    cout << "Enter the number of rows (odd number): ";
    cin >> n;
    cout << "Enter the leading white spaces: ";
    cin >> col;

    pattern(n, col);

    return 0;
}