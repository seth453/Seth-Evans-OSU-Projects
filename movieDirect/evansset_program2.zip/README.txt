How to compile the code using gcc: 

1. To compile the program, type in shell : "--std=gnu99 -o movies_by_year movie.c"  
2. Press enter 
3. Now to run using the executable, type in shell: "movies_by_year" 
4. Press enter 
5. Read prompt and enter choices
