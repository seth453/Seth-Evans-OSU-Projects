#ifndef SHOP_H
#define SHOP_H

#include <string>
#include <fstream>
#include "menu.h"
#include "order.h"

using namespace std;

class Shop {
  private:
    Menu m;
    string phone;
    string address;
    float revenue;
    Order *order_arr;
    int num_orders;
  public:
    //need to include accessor functions and mutator functions for private member when appropriate
    //need to include constructors and destructors where appropriate
    //need to use 'const' when appropriate

    //Suggested functions
    void load_data(); //reads from files to correctly populate coffee, menu, etc.
    void view_shop_detail();
    void search_by_price();
    void search_by_name();
    void place_order();
    void add_to_menu();
    void remove_from_menu();
    void view_orders();

};

#endif
