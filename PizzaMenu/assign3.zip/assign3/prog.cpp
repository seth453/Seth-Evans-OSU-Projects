#include "shop.h"

int main()
{
	//your main function lives here
	return 0;
}